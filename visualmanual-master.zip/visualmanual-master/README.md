# Teachable Machine yordamida yaratilgan modelni mobil ilovaga aylantirish
<br/><br/>Foydalanish uchun:
1. Ushbu reponi kompyuterga yuklab oling
2. Teachable Machien sahifasida model yarating va upload qiling
3. app.js faylini oching va let imageModelURL="" qo'shtirnoq ichida modelga link bering
4. Windows Powershell dasturida repo yuklab olingan papkaga kiring va python -m https.server 8013 komandasini ishga tushuring
5. Chrome brauzerda chrome://flags sahifasiga kiring va insecure origins deb qidiring, yangi oynada kompyutering IP manzili va 8013 portni ko'rsating, Enabled qiling ba Relaunch tugmasini bosing:
![Imgur](https://i.imgur.com/EbKWJkW.jpg)
7. Chromee brauzerda http://<ip_manzil>:8013 manziliga kiring

Video:<br/>

<br/><br/><br/>
Thanks to:
- nurecas/visualmanual
- Teachable Machine : https://teachablemachine.withgoogle.com/
- P5JS : https://p5js.org/
